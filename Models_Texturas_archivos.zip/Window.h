#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	GLfloat getMueveAvionX() { return mueveAvionX; }
	GLfloat getMueveAvionY() { return mueveAvionY; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	bool getUsarArreglo2() { return usarArreglo2; }
	int getColorFaroAvion() { return colorFaroAvion; }
	bool getLuzHolocronOn() { return luzHolocronOn; }
	bool getLuzPinzaOn() { return luzPinzaOn; }
	bool getLuzNaveOn() { return luzNaveOn; }
	bool getLuzMotor1On() { return luzMotor1On; }
	bool getLuzMotor2On() { return luzMotor2On; }
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat muevex;
	GLfloat mueveAvionX;
	GLfloat mueveAvionY;
	bool mouseFirstMoved;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
	bool usarArreglo2 = false; // false = Arreglo 1 | true = Arreglo 2
	int colorFaroAvion = 0;      // 0:Rojo, 1:Amarillo, 2:Verde, 3:Cian, 4:Azul, 5:Magenta
	bool luzHolocronOn = true;   
	bool luzPinzaOn = true;      
	bool luzNaveOn = true;
	bool luzMotor1On = true; 
	bool luzMotor2On = true;

};


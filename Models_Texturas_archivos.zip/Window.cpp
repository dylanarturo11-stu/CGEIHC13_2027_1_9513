#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;
	mueveAvionX = 0.0f;
	mueveAvionY = 0.0f;
	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = 0;
	}
}
int Window::Initialise()
{
	//Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fall� inicializar GLFW");
		glfwTerminate();
		return 1;
	}
	//Asignando variables de GLFW y propiedades de ventana
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//para solo usar el core profile de OpenGL y no tener retrocompatibilidad
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	//CREAR VENTANA
	mainWindow = glfwCreateWindow(width, height, "PracticaXX:Nombre de la practica", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo en crearse la ventana con GLFW");
		glfwTerminate();
		return 1;
	}
	//Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	//asignar el contexto
	glfwMakeContextCurrent(mainWindow);

	//MANEJAR TECLADO y MOUSE
	createCallbacks();


	//permitir nuevas extensiones
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fall� inicializaci�n de GLEW");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	glEnable(GL_DEPTH_TEST); //HABILITAR BUFFER DE PROFUNDIDAD
							 // Asignar valores de la ventana y coordenadas
							 
							 //Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);
	//Callback para detectar que se est� usando la ventana
	glfwSetWindowUserPointer(mainWindow, this);
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}
GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}




void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	//TECLAS ASOCIADAS A LOS MOVIMIENTOS ASIGNADOS AL ROVER
	if (key == GLFW_KEY_E)
	{
		theWindow-> muevex += 1.0;
	}
	if (key == GLFW_KEY_R)
	{
		theWindow-> muevex -= 1.0;
	}
	//TECLAS ASOCIADAS A LOS MOVIMIENTOS ASIGNADOS AL AVION
	// Movimiento del Avi�n en X (Teclas J / L)
	if (key == GLFW_KEY_T && action != GLFW_RELEASE)
	{
		theWindow->mueveAvionX += 0.5f;
	}
	if (key == GLFW_KEY_Y && action != GLFW_RELEASE)
	{
		theWindow->mueveAvionX -= 0.5f;
	}

	// Movimiento del Avi�n en Y (Teclas I / K)
	if (key == GLFW_KEY_U && action != GLFW_RELEASE)
	{
		theWindow->mueveAvionY += 0.5f;
	}
	if (key == GLFW_KEY_I && action != GLFW_RELEASE)
	{
		theWindow->mueveAvionY -= 0.5f;
	}

	if (key == GLFW_KEY_O && action == GLFW_PRESS)
	{
		theWindow->usarArreglo2 = !theWindow->usarArreglo2;
	}
	//CONTROL DEL AVION
	if (key == GLFW_KEY_P && action == GLFW_PRESS)
	{
		theWindow->colorFaroAvion = (theWindow->colorFaroAvion + 1) % 6;
	}
	//CONTROL DEL HOLOCRON
	if (key == GLFW_KEY_F && action == GLFW_PRESS)
	{
		theWindow->luzHolocronOn = !theWindow->luzHolocronOn;
	}
	//CONTROL PINZA
	if (key == GLFW_KEY_G && action == GLFW_PRESS)
	{
		theWindow->luzPinzaOn = !theWindow->luzPinzaOn;
	}

	// CONTROL LUCES DE LA NAVE 
	if (key == GLFW_KEY_H && action == GLFW_PRESS)
	{
		theWindow->luzNaveOn = !theWindow->luzNaveOn;
	}

	// CONTROL MOTOR 1 NAVE 
	if (key == GLFW_KEY_J && action == GLFW_PRESS)
	{
		theWindow->luzMotor1On = !theWindow->luzMotor1On;
	}

	// CONTROL MOTOR 2 NAVE 
	if (key == GLFW_KEY_K && action == GLFW_PRESS)
	{
		theWindow->luzMotor2On = !theWindow->luzMotor2On;
	}

	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
			//printf("se presiono la tecla %d'\n", key);
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
			//printf("se solto la tecla %d'\n", key);
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = xPos;
		theWindow->lastY = yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - yPos;

	theWindow->lastX = xPos;
	theWindow->lastY = yPos;
}


Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();

}
